Low Entropy Component Code Tables
January 23, 2018
Aaron Kiely


For each of the 16 component codes, there is a file code_NN.text defining the component code, and a separate file flush_NN.txt defining the flush table for low-entropy component code NN.

The threshold values are:
	{303336, 225404, 166979, 128672, 95597, 69670, 50678, 34898, 23331, 14935, 9282, 5510, 3195, 1928, 1112, 408}
and the input symbol limit values are:
	{12, 10, 8, 6, 6, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 0}

For each code table file and flush table file, each line of the associated file is of the form
	input, output
Symbols “A”, “B”, “C” are used to represent input values 10, 11, 12 respectively; “X” indicates the escape symbol.

Each output is a binary word represented in hexadecimal, with length (in bits) given. E.g.,
	11'h2FB
represents an 11-bit output having hexadecimal representation 2FB, i.e., 010 1111 1011.

